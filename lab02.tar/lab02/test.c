#include <stdio.h>
#include <string.h>

int main(){
	char buf[50];
	char* string = fgets(buf, 50, stdin);
	printf("%s", string+1);
	return 0;
}