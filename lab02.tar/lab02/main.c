#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){

	int fd1[2], fd2[2];
	char* cmd;
	char buf[100], writebuf[100];
	char write_to_fd[5] = ">&";
	char descr[5];
	pid_t child_pid;
	size_t old_size, new_size;

	if (pipe(fd1) || pipe(fd2)){
		perror("pipe");
		exit(-1);
	}
	sprintf(descr,"%d",fd1[1]);

	cmd = fgets(buf, 50, stdin);
	old_size = strlen(cmd);
	if (cmd[old_size-1] == '\n'){
		cmd[old_size-1] = '\0';
	}

	strcat(write_to_fd,descr);
	strcat(cmd,write_to_fd);

	// printf("КОМАНДА: %s\n", cmd);
	if (-1 == execl(cmd,NULL)){
		perror(cmd);
	}
// перевели данные в fd1
	memset(buf,'\0',old_size); // очищаем буфер
	if((child_pid = fork()) == -1){
        perror("fork");
        exit(-1);
    }
    // azaz = "HEYHEY";
    if (child_pid == 0){ // потомок
    	close (fd1[1]);
    	close (fd2[0]);
    	// printf("synulya: %d\n", getpid());
    	read(fd1[0],buf,sizeof(buf));
    	size_t shift = 0;
    	old_size = strlen(buf);
    	for(size_t i = 0; i < old_size; i++){
    		if (buf[i] == ' ')
    			writebuf[i+shift] = '_';
    		else if(buf[i] == '\t'){
    			for (size_t j = 0; j < 3; j++)
    				writebuf[i+shift+j] = '_';
    			shift += 2;
    		}
    		else
    			writebuf[i+shift]=buf[i];
    	}
    	new_size = old_size + shift;
    	// printf("%s", writebuf);
    	// printf("length is %lu\n", strlen(writebuf));
    	write(fd2[1],writebuf,new_size);
    }
    else{ // предок
    	// char writebuf[100];
    	// new_size = 
		close (fd1[0]);
		close (fd2[1]);
		// printf ("batya: %d\n", getpid());
		// waitpid(child_pid,&status,0);
    	read(fd2[0], buf, sizeof(buf));
    	printf("%s",buf);
	}
	return 0;

}