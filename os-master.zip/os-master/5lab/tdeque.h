#ifndef TDEQUE_H
#define TDEQUE_H


class TDeque
{
public:
    TDeque();
};

#endif // TDEQUE_H