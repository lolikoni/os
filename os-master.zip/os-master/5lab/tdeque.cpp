#include "tdeque.h"

TDeque::TDeque()
{

}
