#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
	char buf[32 ];
	char *file_read = "1.txt";
	char *file_write = "2.txt";
	int fd_rd, fd_wr;

	if ((fd_rd = open(file_read, O_RDONLY)) < 0){
		perror(file_read);
		exit(-1);
	}

	if ((fd_wr = open(file_write, O_WRONLY)) < 0){
		perror(file_write);
		exit(-1);
	}

	read(fd_rd, buf, 10);
	buf[10] = '\n';
	lseek(fd_rd, 5, SEEK_SET);
	if (read(fd_rd, buf, 10) <= 0){
		printf ("read error!\n");
		exit (-1);
	}
	buf[10] = '\n';
	printf("Содержимое буфера:\n");
	write(1, buf, 11);
	printf("%s%s\t", "Запись в ", file_write);

	if (write(fd_wr, buf, 11) <= 0)
		printf ("Ошибка записи\n");
	else
		printf("Успешно!\n");

	close(fd_rd);
	close(fd_wr);
	
	return 0;
}
